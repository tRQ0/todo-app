<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Things to-do</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />

    <!-- Styles -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

</head>

<body>
    <div class="conatiner pt-5">
        <div class="row justify-content-center align-content-center">
            <div class="col col-8">
                <div class="card">
                    <div class="card-header">
                        <form data-action=" <?php echo e(route('todo.store')); ?>" name="addTodo" id="add-todo-form" class="form"
                            method="post">
                            <?php echo csrf_field(); ?>
                            <div class="div row">
                                <div class="col">
                                    <select name="category" class="form-control form-select" required>
                                        <option value="" selected>
                                            Category
                                        </option>
                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value=" <?php echo e($item->id); ?>">
                                                <?php echo e($item->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col">
                                    <input type="text" name="todoItem" class="form-control"
                                        placeholder="Type todo item name" required />
                                </div>
                                <div class="col">
                                    <button type="submit" class="form-control btn btn-outline-primary">Add</button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="card-body">
                        <table name="todoTable" id="todo-table" class="table table-striped table-bordered">
                            <thead class="table-secondary">
                                <tr>
                                    <th>Todo item name</th>
                                    <th>Category</th>
                                    <th>Timestamp</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $item->todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr id="<?php echo e($todo->id); ?>">
                                            <td><?php echo e($todo->name); ?></td>
                                            <td><?php echo e($item->name); ?></td>
                                            <td><?php echo e(date_format($todo->timestamp, 'dS F')); ?></td>
                                            <td class="text-center">
                                                <button type="button" id="remove"
                                                    class="btn btn-danger">Delete</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <div id="message"></div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/create_todo.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/delete_todo.js')); ?>" defer></script>

</body>

</html>
<?php /**PATH E:\Tushar\Development\Laravel\New folder\resources\views/index.blade.php ENDPATH**/ ?>