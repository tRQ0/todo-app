# Things to-do
## Setting up the Project

- import the **seeded_database.sql** into mysql server
- run `composer install` in project directory
- run `php artisan migrate:fresh --seed` in project directory

## Home

- the apps home is at `\` path

<hr>